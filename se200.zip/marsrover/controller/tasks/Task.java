package marsrover.controller.tasks;

/**
* Task interface
*/

public interface Task
{
	public void performTask();
}
